<?php
include("../code/functions.php");
?>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title >ONLINE SHOPPING SITE FOR NURSERY</title>
    <!-- LINKS -->
    <link rel="icon" href="/img/logo.jpg" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/5fe4827def.js" crossorigin="anonymous"></script>
</head>

<style>
    

    .aligncenter {
        text-align: center;
    }

    a {
        color: goldenrod;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    nav {
        background-color: #292b2c;
    }

    .navbar-custom {
        background-color: #292b2c;
    }

    /* change the brand and text color */
    .navbar-custom .navbar-brand,
    .navbar-custom .navbar-text {
        background-color: #292b2c;
    }

    .navbar-custom .navbar-nav .nav-link {
        background-color: #292b2c;
    }

    .navbar-custom .nav-item.active .nav-link,
    .navbar-custom .nav-item:hover .nav-link {
        background-color: #292b2c;
    }


    .mybtn {
        border-color: green;
        border-style: solid;
    }


    .right {
        display: flex;
    }

    .left {
        display: none;
    }

    .cart {

        margin-right: -9px;
    }

    .profile {
        margin-right: 2px;

    }

    .login {
        margin-right: -2px;
        margin-top: 12px;
        display: none;
    }

    .searchbox {
        width: 60%;
    }

    .lists {
        display: inline-block;
    }

    .moblists {
        display: none;
    }

    .logins {
        text-align: center;
        margin-right: -30%;
        margin-left: 35%;
    }

    .table {
        width: 100%;
        border-collapse: collapse;
    }

    .table td,
    .table th {
        padding: 8px 8px;
        border: 0.5px solid black;
        text-align: center;
        font-size: 16px;
        background-color: white;
    }

    .table thead th {
        vertical-align: bottom;
        border-bottom: 0px solid #dee2e6;
    }

    .table th {
        background-color: #292b2c;
        color: white;
    }

    .table tbody tr:nth-child(even) {
        background-color: #f5f5f5;
    }

    .add {
        width: 40%;
    }

    @media only screen and (min-device-width:320px) and (max-device-width:480px) {


        .right {
            display: none;
            background-color: #ff5500;

        }


        .left {
            display: flex;
        }

        .moblogo {
            display: none;
        }

        .logins {
            text-align: center;
            margin-right: 35%;
            padding: 15px;
        }

        .searchbox {
            width: 95%;
            margin-right: 5%;
            margin-left: 0%;
        }

        .moblists {
            display: inline-block;
            text-align: center;
            width: 100%;
        }

        .table thead {
            display: none;
            background-color: #292b2c;
            color: goldenrod;
        }

        .table,
        .table tbody,
        .table tr,
        .table td {
            display: block;
            width: 100%;

        }

        .table tr {
            margin-bottom: 15px;

        }

        .table td {
            text-align: right;
            padding-left: 50%;
            text-align: right;
            position: relative;


        }

        .table td::before {
            content: attr(data-label);
            position: absolute;
            left: 0;
            width: 50%;
            padding-left: 15px;
            font-size: 15px;
            font-weight: bold;
            text-align: left;
            /* background-color: #292b2c;
        color: goldenrod; */
        }

        .add {
            width: auto;
        }

        .emptycart {
            /* margin-left: 20%;
            width:80%;  */
            float: none;
            text-align: center;

        }

        .continueshopping {
            /* margin-top:20%;
            margin-left: 20%;  */
            float: none;
            text-align: center;
            margin-top: -20%;

        }

        .grandtotal {
            /* margin-right: 20%; */
            float: none;
            margin-top: 40%;
        }
    }
</style>

<body>
    <!-- navbar -->
 <nav class="navbar navbar-expand-lg bg-light">
   <div class="container">
     <a class="navbar-brand" href="#"><img src="../img/logo.jpg"height="50" width="50" alt=""></a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
     </button>
     <div class="collapse navbar-collapse" id="navbarSupportedContent">
       <ul class="navbar-nav me-auto mb-2 mb-lg-0">
         <li class="nav-item">
           <a href="buyerhome.php" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">home</a>
           <!-- <a class="nav-link active" aria-current="page" href="#">home</a> -->
         
         </li>
         <li class="nav-item">
           <a href="http://127.0.0.1:5500/code/shop.html" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">shop</a>
          <!-- <a class="nav-link active" aria-current="page" href="#">Shop</a> -->
         </li>
         <li class="nav-item">
           <a href="#" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">profile</a>
           <!-- <a class="nav-link active" aria-current="page" href="#">profile</a> -->
         </li>
         <!---->
         <div class="dropdown">
           <button class="btn btn-dark dropdown-toggle me-md-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
             products
           </button>
           <ul class="dropdown-menu">
             <li><a class="dropdown-item" href="#">plants</a></li>
             <li><a class="dropdown-item" href="#">gardening tools</a></li>
             <li><a class="dropdown-item" href="#">fertilizers</a></li>
           </ul>
         </div>
         <li class="nav-item">
           <a href="cart.php" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">cart</a>
           <!-- <a class="nav-link active" aria-current="page" href="#">profile</a> -->
         </li>
         
       </ul>
       <!-- search bar -->
       <form class="d-flex" role="search">
         <input class="form-control me-2"  type="search" placeholder="looking for anything ?" aria-label="Search">
         <button class="btn btn-outline-success" type="submit">  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
           <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007
           1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
          </svg></button>
       </form>
     </div>
   </div>
 </nav>
 
 <div class="container">

  <?php
  if (isset($_SESSION['phonenumber'])) {
      $temp = totalItems();
      echo   "<div class='text-left'>
                  <h3>Your Items :- $temp</h3>
                  <hr>";
  }
  ?>

  <table class="table">
      <thead>
          <th>S.No</th>
          <th>Item Name</th>
          <th>Unit Price </th>
          <th style="width:25%;">Quantity</th>
          <th>Subtotal</th>
          <th>Delete</th>
      </thead>

      <?php
      $total = 0;
      global $con;
      if (isset($_SESSION['phonenumber'])) {
          $sess_phone_number = $_SESSION['phonenumber'];
          $sel_price = "select * from cart where phonenumber = '$sess_phone_number'";
          $run_price = mysqli_query($con, $sel_price);

          $qtycart = array();
          $i = 0;
          while ($p_price = mysqli_fetch_array($run_price)) {
              $product_id = $p_price['product_id'];
              $_SESSION['qtycart'][$i] = $p_price['qty'];

              $pro_price = "select * from products where product_id='$product_id'";
              $run_pro_price = mysqli_query($con, $pro_price);
              while ($pp_price = mysqli_fetch_array($run_pro_price)) {
                  $product_title = $pp_price['product_title'];
                  $product_price = $pp_price['product_price'];
                  $subtotal = $_SESSION['qtycart'][$i] * $product_price;

      ?>



                  <!-- <td class="tdy" data-label="quantity"><a style="color:black;margin-right:12px;" href="MinusQty.php?id=<?php echo $product_id; ?>"><label class="add ladd"><i style="padding: 4px;" class=" icon left  fas fa-minus">
                              </label></a></i>
                          <input type="number" oninput="this.value = Math.abs(this.value)" min="1" value='<?php echo $_SESSION['qtycart'][$i]; ?>' name="qty" style="width:40px; "><a style="color:black;margin-left:4px;" href="AddQty.php?id=<?php echo $product_id; ?>"><label class="add radd">
                                  <i style="padding: 4px;" class="icon right  fas fa-plus"></label></a></i></td>
                      </td> -->


                  <tbody>
                      <tr>
                          <td data-label="S.No" style="font-size:20px;"><?php echo $i + 1; ?></td>
                          <td data-label="Item Name " style="font-size:20px;"><?php echo $product_title; ?></td>
                          <td data-label="Unit Price" style="font-size:20px;"><?php echo $product_price; ?></td>

                          <td data-label="Quantity p-0 " style="padding-top:1.5%;padding-bottom:-2%">
                              <div class="d-flex justify-content-center " style="width:90%;padding-left:10%;">
                                  <div class="input-group mb-3">
                                      <div class="input-group-prepend">
                                          <a href="AddQty.php?id=<?php echo $product_id; ?>">
                                              <button class="btn btn-outline-secondary" style=" background-color:#292b2c;" type="button" id="button-addon1">
                                                  <b style="color:white"><i class="fas fa-plus"></i></b>
                                              </button>
                                          </a>
                                      </div>
                                      <input type="number" class="form-control" oninput="this.value = Math.abs(this.value)" min="1" value='<?php echo $_SESSION['qtycart'][$i]; ?>' name="qty" placeholder="" aria-label="Example text with button addon" aria-describedby="button-addon1">
                                      <div class="input-group-append">
                                          <a href="MinusQty.php?id=<?php echo $product_id; ?>">
                                              <button class="btn btn-outline-secondary" style=" background-color:#292b2c;" type="button" id="button-addon2">
                                                  <b style="color:white"><i class="fas fa-minus"></i></b>
                                              </button>
                                          </a>
                                      </div>
                                  </div>
                              </div>
                          </td>


                          <?php $subtotal = $_SESSION['qtycart'][$i] * $product_price; ?>
                          <?php
                          $subquery = "update cart set subtotal = $subtotal where product_id = $product_id";
                          $run = mysqli_query($con, $subquery);
                          ?>

                          <td data-label="Subtotal" style="font-size:20px;"><?php echo $subtotal; ?></td>
                          <?php $total = $total + $subtotal ?>
                          <td data-label="Delete" style="font-size:20px;"><a href="deleteproductcart.php?id=<?php echo $product_id; ?>" id="Deletionlink"><i class="far fa-times-circle"></i></a></td>
                      </tr>
          <?php
              }
              $i++;
          }
      } else {
          echo "<h1 align = center>Please Login First!</h1><br><br><hr>";
      } ?>

                  </tbody>
  </table>

</div>

  <div class="container">
        <div class="float-none float-sm-none float-md-none float-lg-left float-xl-left  emptycart">
            <a href="emptycart.php">
                <button type="button" class="btn btn-lg  border border-dark " style="font-size:22px;color:white;background-color:#fb774b">Empty Cart
                    <i class="fas fa-shopping-cart ml-1"></i></button>
            </a>
        </div>
        <!-- <div class="grandtotal  float-none float-sm-none float-md-none float-lg-right float-xl-right"></div><br> -->
        <br>
        <div class=" float-none float-sm-none float-md-none float-lg-right float-xl-rightcheckout mr-0 p-2 border border-dark  " style="border-radius:5%;">

            <h2>Grand total = Rs <?php echo $total; ?> </h2>

            <?php
            if (isset($_SESSION['phonenumber'])) {
                $sel_price = "select * from cart where phonenumber = '$sess_phone_number'";
                $run_price = mysqli_query($con, $sel_price);
                $count = mysqli_num_rows($run_price);
                if ($count > 0) {
                    echo "<a href='checkout.php'>
                                <button type='button' class='btn btn-lg border border-dark d-flex mx-auto' style='font-size:22px;color:white;background-color:#fb774b'>
                                    Checkout<i class='fas fa-arrow-right ml-2 mt-2 mb-1'></i>
                                </button>
                            </a>";
                } else {

                    echo "<a href='../code/alert.php'>
                                <button type='button' class='btn btn-lg border border-dark d-flex mx-auto' style='font-size:22px;color:white;background-color:#fb774b'>
                                    Checkout<i class='fas fa-arrow-right ml-2 mt-2 mb-1'></i>
                                </button>
                            </a>";
                }
            } else {

                echo "<a href='../code/buyerlogin.php'>
                                <button type='button' class='btn btn-lg border border-dark d-flex mx-auto' style='font-size:22px;color:white;background-color:#fb774b'>
                                    Checkout<i class='fas fa-arrow-right ml-2 mt-2 mb-1'></i>
                                </button>
                            </a>";
            }
           ?>

        </div>

        <?php $_SESSION['grandtotal'] = $total; ?>
        <br>
        <br>
        <div class=" float-none float-sm-none float-md-none float-lg-left float-xl-left continueshopping mt-5">
            <a href="buyerhome.php"><button type="button" class="btn btn-lg  border border-dark " style="font-size:22px;color:white;background-color:#fb774b">Continue Shopping
                    <i class="fas fa-shopping-bag ml-1"></i></button></a>
        </div>
</div>


 </body>
 
 <!--footer-->
 <footer class="mt-5 py-1">
  <div class="row container mx-auto pt-5">
    <div class="footer-one col-lg-3 col-md-6 col-12">
      <img src="../img/logo.jpg">
      <p>The website where you can buy all different types of plants in single place. Can buy seeds, pots, necessary tools and fertilizers.</p>
    </div>
   <div class="footer-one col-lg-3 col-md-6 col-12">
     <h6 class="pb-2">Featured</h6>
     <ul class="text-uppercase list-unstyled">
       <li><a href="#">plants</a></li>
       <li><a href="#">fertilizers</a></li>
       <li><a href="#">pots</a></li>
       <li><a href="#">seeds</a></li>
       <li><a href="#">pebbles</a></li>
       <li><a href="#">accessories</a></li>
      </ul>
   </div>
   <div class="footer-one col-lg-3 col-md-6 col-12">
      <h6 class="pb-2" >MADE BY:</h6>
     <div>
       <h6 class="text-uppercase"> team members:</h6>
       <p>B.NARESH<br>A.KARTHIK<br>K.SAI PUNEETH</p>
     </div>
     <div>
       <h6 class="text-uppercase"> mail id:</h6>
       <p>20H51A0532@cmrcet.ac.in<br>20H51A0536@cmrcet.ac.in<br>20H51A0596@cmrcet.ac.in</p>
     </div>
   </div>
  </div>
  <div class="row container mx-autp">
    <div class="col-lg-3 col-md-6 col-12">
      <img src="../img/payment.jpg" height="100" width="500">
     </div>
   
  </div>
</footer>
