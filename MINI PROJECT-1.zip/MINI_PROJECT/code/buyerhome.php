<?php
include("../code/functions.php");
?>
<html lang="en">
  
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title >ONLINE SHOPPING SITE FOR NURSERY</title>
    <!-- LINKS -->
    <link rel="icon" href="/img/logo.jpg" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/5fe4827def.js" crossorigin="anonymous"></script>
</head>

<body>
  <!-- navbar -->
  <nav class="navbar navbar-expand-lg bg-light">
    <div class="container">
      <a class="navbar-brand" href="#"><img src="../img/logo.jpg"height="50" width="50" alt=""></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a href="buyerhome.php" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">Home</a>
            <!-- <a class="nav-link active" aria-current="page" href="#">home</a> -->
          
          </li>
          <li class="nav-item">
            <a href="shop.html" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">Shop</a>
           <!-- <a class="nav-link active" aria-current="page" href="#">Shop</a> -->
          </li>
          <li class="nav-item">
            <a href="buyerprofile.php" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">Profile</a>
            <!-- <a class="nav-link active" aria-current="page" href="#">profile</a> -->
          </li>
          <!---->
          <div class="dropdown">
            <button class="btn btn-dark dropdown-toggle me-md-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
              Products
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">Plants</a></li>
              <li><a class="dropdown-item" href="#">Gardening tools</a></li>
              <li><a class="dropdown-item" href="#">Fertilizers</a></li>
            </ul>
          </div>
          <li class="nav-item">
            <a href="cart.php" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">cart</a>
            <!-- <a class="nav-link active" aria-current="page" href="#">profile</a> -->
          </li>
          
        </ul>
        <!-- search bar -->
        <div class="search_input">
			<form action="searchresult.php" method="get" enctype="multipart/form-data">
				
        <button class="btn btn-outline-success" type="submit">  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
            <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007
            1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
           </svg></button>
				<input type="text" id="input1" name="search" placeholder="looking for anything ?">
			</form>
		</div>
      </div>
    </div>
  </nav>
  <!--pop up message.-->
  <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
   <div class="toast-header">
     <img src="..." class="rounded me-2" alt="...">
     <strong class="me-auto">Bootstrap</strong>
     <small>11 mins ago</small>
     <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
   </div>
    <div class="toast-body">
     hello this is a popup message.
    </div>
  </div>
  
<!--slide ad.-->
<div id="carouselExampleIndicators" class="carousel carousel-dark slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active ">
      <div class="d-flex justify-content-center">
       <img src="../img/snake plant.jpg"  height="300px" width="900px" alt="...">
      </div>
    </div>
    <div class="carousel-item">
      <div class="d-flex justify-content-center">
       <img src="../img/luckey plant.jpg" height="300px" width="900px" alt="...">
      </div>
    </div>
    <div class="carousel-item">
      <div class="d-flex justify-content-center">
       <img src="../img/spider plant.jpeg" height="300px" width="900px" alt="...">
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<!-- tools -->
<section id="new" class="container py-5">
  <div class="row">
    <div class="one col-lg-2 col-md-4 col-6 me-md-3">
      <img class="img-fluid" src="../img/types/gardening.jpeg">
      <div class="details">
        <h2>Gardening</h2>
      </div>
    </div>
    <div class="one col-lg-2 col-md-4 col-6 me-md-3">
      <img class="img-fluid" src="../img/types/seeds.jpeg" >
      <div class="details">
        <h2>Seeds</h2>
      </div>
    </div>
    <div class="one col-lg-2 col-md-4 col-6 me-md-3">
      <img class="img-fluid" src="../img/types/organic fertilizer.jpeg">
      <div class="details">
        <h2>Fertilizer</h2>
      </div>
    </div>
    <div class="one col-lg-2 col-md-4 col-6 me-md-3">
      <img class="img-fluid" src="../img/types/pots.jpeg">
      <div class="details">
        <h2>Pots</h2>
      </div>
    </div>
    <div class="one col-lg-2 col-md-4 col-6 me-md-3">
      <img class="img-fluid" src="../img/types/accessories.jpeg">
      <div class="details">
        <h2>Accessories</h2>
      </div>
    </div>
    
  </div>
</section>

<!--best seller-->
<section id="new" class="my-5 pb-5">
  <div class="container text-center mt-5 py3">
    <h3>BEST SELLLER</h3>
    <hr class="mx-auto">
    <p>Here you can check best selling products</p>
  </div>
  
  <div class="row mx-auto container-fluid">
    <div onclick="window.location.href='peace lily.html';" class="product text-center col-lg-3 col-md-4 col-12">
      <img class="img-fluid mb-3" src="../img/best seller/peace lily.jpeg" height="250" width="175" >
      <div class="star">
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
      </div>
      <h4 class="p-name">Peace Lily</h4>
      <h5 class="p-price">₹299</h5>
      <button type="button" class="buy-btn">Buy Now</button>
    </div>
    <div onclick="window.location.href='bonsai.html';" class="product text-center col-lg-3 col-md-4 col-12">
      <img class="img-fluid mb-3" src="../img/best seller/bonsai.jpeg" height="250" width="280">
      <div class="star">
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
      </div>
      <h4 class="p-name">bonsai</h4>
      <h5 class="p-price">₹2500</h5>
      <button class="buy-btn">Buy Now</button>
    </div>
    <div  class="product text-center col-lg-3 col-md-4 col-12">
      <img class="img-fluid mb-3" src="../img/best seller/rose.jpeg">
      <div class="star">
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
      </div>
      <h4 class="p-name">rose</h4>
      <h5 class="p-price">₹399</h5>
      <button class="buy-btn">Buy Now</button>
    </div>
    <div class="product text-center col-lg-3 col-md-4 col-12">
      <img class="img-fluid mb-3" src="../img/best seller/spray.jpg" height="220" width="220">
      <div class="star">
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
      </div>
      <h4 class="p-name">spray</h4>
      <h5 class="p-price">₹220</h5>
      <button class="buy-btn">Buy Now</button>
    </div>
  </div>
  
</section>

<!-- banner-->
<section id="banner" class="my-5 py-5">
  <div class="container">
    <h4>MID SEASON'S SALE</h4>
    <h1>GARDENING TOOLS <br> UPTO 20% OFF</h1>
    <button class="buy-btn">Shop Now</button>
  </div>
</section>

<!-- new additions-->
<section id="new " class="my-5 ">
  <div class="container text-center mt-5 py3">
    <h3>NEW ADDITIONS</h3>
    <hr class="mx-auto">
    <p>Here you can check new additions</p>
  </div>
  
  <div class="row mx-auto container-fluid">
    <div class="product text-center col-lg-3 col-md-4 col-12">
      <img class="img-fluid mb-3" src="../img/new additions/vermi compost.jpg" height="250" width="200" >
      <div class="star">
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
      </div>
      <h4 class="p-name">vermi compost</h4>
      <h5 class="p-price">₹299</h5>
      <button type="button" class="buy-btn">Buy Now</button>
    </div>
    <div class="product text-center col-lg-3 col-md-4 col-12">
      <img class="img-fluid mb-3" src="../img/new additions/red soil.jpg" height="250" width="200">
      <div class="star">
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
      </div>
      <h4 class="p-name">red soil</h4>
      <h5 class="p-price">₹250</h5>
      <button class="buy-btn">Buy Now</button>
    </div>
    <div class="product text-center col-lg-3 col-md-4 col-12">
      <img class="img-fluid mb-3" src="../img/new additions/multi colored pebbles.jpg" height="100" width="200">
      <div class="star">
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
      </div>
      <h4 class="p-name">multi colored pebbles</h4>
      <h5 class="p-price">₹399</h5>
      <button class="buy-btn">Buy Now</button>
    </div>
    <div class="product text-center col-lg-3 col-md-4 col-12">
      <img class="img-fluid mb-3" src="../img/new additions/hanging pot.jpg" height="220" width="220">
      <div class="star">
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
      </div>
      <h4 class="p-name">hanging pot</h4>
      <h5 class="p-price">₹220</h5>
      <button class="buy-btn">Buy Now</button>
    </div>
  </div>
  
</section>

<!--plants that attract butterfly-->
<section id="new" class="my-5 ">
  <div class="container text-center mt-5 py3">
    <h3>BUTTERFLY ATTRACTING PLANTS</h3>
    <hr class="mx-auto">
    <p>Here you can check plants that attract butterfly's.</p>
  </div>
  
  <div class="row mx-auto container-fluid">
    <div class="product text-center col-lg-3 col-md-4 col-12">
      <img class="img-fluid mb-3" src="../img/butterfly/goldenrod.jpeg" height="250" width="300" >
      <div class="star">
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
      </div>
      <h4 class="p-name">goldenrod</h4>
      <h5 class="p-price">₹299</h5>
      <button type="button" class="buy-btn">Buy Now</button>
    </div>
    <div class="product text-center col-lg-3 col-md-4 col-12">
      <img class="img-fluid mb-3" src="../img/butterfly/penta.jpeg" height="150" width="170">
      <div class="star">
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
      </div>
      <h4 class="p-name">penta</h4>
      <h5 class="p-price">₹250</h5>
      <button class="buy-btn">Buy Now</button>
    </div>
    <div class="product text-center col-lg-3 col-md-4 col-12">
      <img class="img-fluid mb-3" src="../img/butterfly/phlox.jpeg" height="80" width="300">
      <div class="star">
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
      </div>
      <h4 class="p-name">phlox</h4>
      <h5 class="p-price">₹399</h5>
      <button class="buy-btn">Buy Now</button>
    </div>
    <div onclick="window.location.href='blue star.html';" class="product text-center col-lg-3 col-md-4 col-12">
      <img class="img-fluid mb-3" src="../img/butterfly/bluestar.jpeg" height="220" width="340">
      <div class="star">
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
      </div>
      <h4 class="p-name">bluestar</h4>
      <h5 class="p-price">₹220</h5>
      <button class="buy-btn">Buy Now</button>
    </div>
  </div>
  
</section>

<!--best products-->
<div class="container">

        <div class="text-center">
            <h1 id="headings" class="longguard"><span><b>Best Selling Products All Over India </b></span>
            </h1>
            <hr class="mx-auto">
        </div>
        <br>
        <div class="row">
            <?php
            cart();
            getProducts();
            ?>
        </div>
        <br><br>


</div>

  <!--pagination-->
<div class="pagination justify-content-center">
<nav aria-label="Page navigation example">
  <ul class="pagination justify-content-center" >
    <li class="page-item">
      <a class="page-link" href="#" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
      </a>
    </li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item">
      <a class="page-link" href="#" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
</nav>
</div>

<!--footer-->
<footer class="mt-5 py-1">
  <div class="row container mx-auto pt-5">
    <div class="footer-one col-lg-3 col-md-6 col-12">
      <img src="../img/logo.jpg">
      <p>The website where you can buy all different types of plants in single place. Can buy seeds, pots, necessary tools and fertilizers.</p>
    </div>
   <div class="footer-one col-lg-3 col-md-6 col-12">
     <h6 class="pb-2">Featured</h6>
     <ul class="text-uppercase list-unstyled">
       <li><a href="#">plants</a></li>
       <li><a href="#">fertilizers</a></li>
       <li><a href="#">pots</a></li>
       <li><a href="#">seeds</a></li>
       <li><a href="#">pebbles</a></li>
       <li><a href="#">accessories</a></li>
      </ul>
   </div>
   <div class="footer-one col-lg-3 col-md-6 col-12">
      <h6 class="pb-2" >MADE BY:</h6>
     <div>
       <h6 class="text-uppercase"> team members:</h6>
       <p>B.NARESH<br>A.KARTHIK<br>K.SAI PUNEETH</p>
     </div>
     <div>
       <h6 class="text-uppercase"> mail id:</h6>
       <p>20H51A0532@cmrcet.ac.in<br>20H51A0536@cmrcet.ac.in<br>20H51A0596@cmrcet.ac.in</p>
     </div>
   </div>
  </div>
  <div class="row container mx-autp">
    <div class="col-lg-3 col-md-6 col-12">
      <img src="../img/payment.jpg" height="100" width="500">
     </div>
   
  </div>
</footer>

<script src="script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" 
    integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" 
    integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>
    <script src="js/bootstrap.js"></script>
</body>

</html>