<?php
include("../code/functions.php");
?>
<html lang="en">
  
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title >ONLINE SHOPPING SITE FOR NURSERY</title>
    <!-- LINKS -->
    <link rel="icon" href="/img/logo.jpg" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/5fe4827def.js" crossorigin="anonymous"></script>
<style>
  .table {
        width: 100%;
        border-collapse: collapse;
    }

    .table td,
    .table th {
        padding: 10px 10px;
        border: 1px solid #ddd;
        text-align: center;
        font-size: 16px;
    }

    .table th {
        background-color: #292b2c;
        color: white;
    }

    .table tbody tr:nth-child(even) {
        background-color: #f5f5f5;
    }

    .goback {
        /* text-align:none; */
        width: 20%;
        /* margin-left:10%; */
        margin-right: -7%;
        margin-left: 0%
    }

    .placeorder {
        /* text-align:none; */
        width: 20%;
        margin-right: -3.5%;
    }
  </style>
</head>

<body>
  <!-- navbar -->
  <nav class="navbar navbar-expand-lg bg-light">
    <div class="container">
      <a class="navbar-brand" href="#"><img src="../img/logo.jpg"height="50" width="50" alt=""></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a href="index.html" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">Home</a>
            <!-- <a class="nav-link active" aria-current="page" href="#">home</a> -->
          
          </li>
          <li class="nav-item">
            <a href="shop.html" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">Shop</a>
           <!-- <a class="nav-link active" aria-current="page" href="#">Shop</a> -->
          </li>
          <li class="nav-item">
            <a href="buyerprofile.php" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">Profile</a>
            <!-- <a class="nav-link active" aria-current="page" href="#">profile</a> -->
          </li>
          <!---->
          <div class="dropdown">
            <button class="btn btn-dark dropdown-toggle me-md-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
              Products
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">Plants</a></li>
              <li><a class="dropdown-item" href="#">Gardening tools</a></li>
              <li><a class="dropdown-item" href="#">Fertilizers</a></li>
            </ul>
          </div>
          <li class="nav-item">
            <a href="cart.php" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">cart</a>
            <!-- <a class="nav-link active" aria-current="page" href="#">profile</a> -->
          </li>
          
        </ul>
        <!-- search bar -->
        <form class="d-flex" role="search">
      <input class="form-control me-2"  type="search" id="search-item" placeholder="Search products " aria-label="Search" onkeyup="search()">
          <button class="btn btn-outline-success" type="submit">  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
             class="bi bi-search" viewBox="0 0 16 16">
            <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007
            1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
           </svg></button>
        </form>
      </div>
    </div>
  </nav>
  <form action="checkout.php" method="post">
        <?php
        $phonenumber = $_SESSION['phonenumber'];
        $get_addr = "select buyer_addr from buyer_registration where buyer_phone=$phonenumber";
        $run = mysqli_query($con, $get_addr);
        while ($row = mysqli_fetch_array($run)) {
            $buyer_addr = $row['buyer_addr'];
        }
        ?>

        <div class="container mt-2">
            <div class="text">
                <br>
                <h3 style="font-family:Georgia, 'Times New Roman', Times, serif">Check your address </h3>
            </div>
            <hr style="margin-top:-0.5%">
            <form>
                <div class=" float-none float-sm-none float-md-none float-lg-right float-xl-rightcheckout mr-0 p-2 mb-5   " style="border-radius:5%;">
                    <h4 style="font-family: sans-serif"><b>Grand total = Rs. <?php echo $_SESSION['grandtotal']; ?> </b></h4>
                </div>
                <div class="input-group mt-2 hey ">
                    <div class="input-group-prepend ">
                        <span class="input-group-text" style="background-color:#292b2c;color:white">Delivery Address</span>
                    </div>
                    <textarea class="form-control" name="address" aria-label="With textarea"><?php echo $buyer_addr ?></textarea>
                </div>
        </div>
        <div class="container mt-5">
            <div class="text">
                <h3 style="font-family:Georgia, 'Times New Roman', Times, serif">Check your Items </h3>
            </div>
            <hr style="margin-top:-0.5%">
            <table class="table">
                <thead>
                    <th>Serial No</th>
                    <th>Name</th>
                    <th>Total (in Rs)</th>
                    <th>Delivery options</th>
                    <!-- <th>Status</th> -->
                </thead>



                <?php

                global $con;
                if (isset($_SESSION['phonenumber'])) {
                    $sess_phone_number = $_SESSION['phonenumber'];
                    $sel_price = "select * from cart where phonenumber = '$sess_phone_number'";
                    $run_price = mysqli_query($con, $sel_price);
                    $i = 0;

                    $allproducts = array();
                    $allqty = array();
                    $allsubtotal = array();
                    $allphones = array();
                    while ($p_price = mysqli_fetch_array($run_price)) {
                        $product_id = $p_price['product_id'];
                        $qty = $p_price['qty'];
                        $subtotal = $p_price['subtotal'];
                        array_push($allproducts, $product_id);
                        array_push($allqty, $qty);

                        $pro_price = "select * from products where product_id='$product_id'";
                        $run_pro_price = mysqli_query($con, $pro_price);
                        while ($pp_price = mysqli_fetch_array($run_pro_price)) {
                            $product_title = $pp_price['product_title'];
                            $nurseryman_fk = $pp_price['nurseryman_fk'];

                            $get_phone = "select * from nurseryregistration where nurseryman_id = $nurseryman_fk";
                            $run_get_phone = mysqli_query($con, $get_phone);
                            while ($phones = mysqli_fetch_array($run_get_phone)) {
                                $phone = $phones['nurseryman_phone'];
                                array_push($allphones, $phone); ?>


                                <tbody>
                                    <tr>
                                        <td data-label="Sr.No"><?php echo $i + 1; ?></td>
                                        <td data-label="Name"><?php echo $product_title; ?></td>
                                        <td data-label="Total (in Rs)"><?php echo $subtotal; ?></td>
                                        <?php
                                        array_push($allsubtotal, $subtotal); ?>
                                        <td data-label=">Delivery options">
                                            <select class="custom-select custom-select" name="delivery">
                                                <option selected value="Farmer">nurseryman</option>
                                                <option value="Buyer">Buyer</option>
                                                <option value="Courier">Courier</option>
                                            </select>
                                        </td>
                                    </tr>
                                </tbody>

                <?php
                            }
                        }
                        $i++;
                    }
                } else {
                    echo "<h1 align = center>Please Login First!</h1><br><br><hr>";
                } ?>
            </table>
        </div>

        <div class="container mt-5">
            <div class="text">
                <h3 style="font-family:Georgia, 'Times New Roman', Times, serif">Select Your Payment Mode</h3>
            </div>
            <hr style="margin-top:-0.5%">

            <div class="payment">
                <h4>Payment Options :-
                    <input type="radio" aria-label="Radio button for following text input" name="payment" value="paytm" required>
                    <img src="../img/paytm1.jpg" alt="paytm" class="paytm">
                    <input type="radio" aria-label="Radio button for following text input" name="payment" value="cod" required>
                    <img src="../img/cod.jpg" alt="paytm" class="cod" style="height:37px">
                </h4>
            </div>

            <div class="float-none float-sm-none float-md-none float-lg-right float-xl-right placeorder">
                <a href="#"><button type="submit" name="submit" class="btn btn-lg  border border-dark " style="font-size:22px;color:white;background-color:#fb774b">
                        Place Order
                        <i class="fas fa-thumbs-up"></i>
                    </button>
                </a>
            </div>
    </form>



    <br> <br><br>
    <div class="float-none float-sm-none float-md-none float-lg-right float-xl-right goback ">
        <a href="cart.php"><button type="button" class="btn btn-lg  border border-dark  " style="font-size:22px;color:white;background-color:#000;margin-left:-8%;">
                <i class="fas fa-arrow-left"></i> Go Back </button></a>
    </div>
    </div>
</body>
</html>
<?php
if (isset($_POST['submit'])) {
    $address = $_POST['address'];
    $delivery = $_POST['delivery'];
    $payment = $_POST['payment'];
    $total = $_SESSION['grandtotal'];

    $count = 0;
    while ($count < $i) {
        $product_id = $allproducts[$count];
        $qty = $allqty[$count];
        $total = $allsubtotal[$count];
        $phone = $allphones[$count];
        $query1 = "insert into orders (product_id,qty,address,delivery,phonenumber,total,payment,buyer_phonenumber) values ('$product_id','$qty','$address','$delivery','$phone','$total','$payment','$sess_phone_number')";
        $run = mysqli_query($con, $query1);
        $count = $count + 1;
    }
    $clear = "delete from cart where phonenumber = $sess_phone_number";
    $run = mysqli_query($con, $clear);
    if ($run) {
        echo "<script>window.open('Success.php','_self')</script>";
    }
}
?>