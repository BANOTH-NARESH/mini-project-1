CREATE DATABASE  IF NOT EXISTS `nursery1`;
USE `nursery1`;

CREATE TABLE `buyer_registration` (
  `buyer_id` int(255) NOT NULL,
  `buyer_name` varchar(30) NOT NULL,
  `buyer_phone` bigint(10) NOT NULL,
  `buyer_addr` text NOT NULL,
  `buyer_mail` varchar(20) NOT NULL,
  `buyer_username` varchar(20) NOT NULL,
  `buyer_password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `buyer_registration` (`buyer_id`, `buyer_name`, `buyer_phone`, `buyer_addr`, `buyer_mail`, `buyer_username`, `buyer_password`) VALUES
(1, 'Abhishek', 1234567890,'kompally','Abhishek@gmail.com','Abhishek','Abhishek'),
(2, 'Arpit', 7666610976,'Ameerpet','Arpitk@gmail.com','Arpit','Arpit' ),
(3, 'shiva', 2589631472,'Sanathnagar','shiva@gmail.com','shiva','shiva' ),
(4, 'Lokesh', 9029788504,'Khairatabad','Lokesh@gmail.com','Lokesh','Lokesh' ),
(5, 'naresh', 9819104641, 'Musheerabad','naresh@gmail.com','naresh','naresh'),
(6, 'bhanu', 8828071232, 'Secunderabad','bhanu@gmail.com','bhanu','bhanu');

CREATE TABLE `cart` (
  `product_id` int(255) NOT NULL,
  `phonenumber` bigint(10) NOT NULL,
  `qty` int(10) NOT NULL DEFAULT 1,
  `subtotal` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `cart` (`product_id`, `phonenumber`, `qty`, `subtotal`) VALUES
(7, 8169193101, 2, 10);

CREATE TABLE `categories` (
  `cat_id` int(11) NOT NULL,
  `cat_title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(8, 'plants'),
(9, 'seeds'),
(10, 'tools'),
(11, 'fertilizer'),
(12, 'pots_for_plants');

CREATE TABLE `nurseryregistration` (
  `nurseryman_id` int(255) NOT NULL,
  `nurseryman_name` varchar(255) NOT NULL,
  `nurseryman_phone` bigint(10) NOT NULL,
  `nurseryman_address` text NOT NULL,
  `nurseryman_state` varchar(50) NOT NULL,
  `nurseryman_district` varchar(50) NOT NULL,
  `nurseryman_pan` varchar(10) NOT NULL,
  `nurseryman_bank` int(16) NOT NULL,
  `nurseryman_password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `nurseryregistration` (`nurseryman_id`, `nurseryman_name`, `nurseryman_phone`, `nurseryman_address`, `nurseryman_state`, `nurseryman_district`, `nurseryman_pan`, `nurseryman_bank`, `nurseryman_password`) VALUES
(13, 'omkar', 8169193102, 'kannadi', 'KERALA', 'Alappuzha', '123ABC', 45745425, 'omkar'),
(14, 'Ram', 8169193103, 'tamsa', 'MahaRASHTRA', 'nanded', '123ABC', 211324654, 'Ram'),
(15, 'Lokesh', 8169193104, 'patwai', 'Uttar Pradesh', 'rampur', '1325355', 45745425, 'Lokesh'),
(16, 'Rohan', 8169193105, 'atmakur', 'Telangana', 'warangal', '1234567899', 2147483647, 'Rohan'),
(17, 'sachit', 8169193106, 'agaram', 'Tamil Nadu', 'vellore', '5341874510', 2147483647, 'sachit'),
(18, 'vinay', 8169193107, 'raigadh', 'Gujarat', 'tapi', '6846516843', 2147483647, 'vinay'),
(19, 'nithin', 8169193108, 'tissa', 'HIMACHAL PRADESH', 'Chamba', '3263062', 56878613, 'nithin'),
(20, 'vijay', 8169193109, 'durgi', 'Andhra Pradesh', 'guntur', '2983473057', 2147483647, 'vijay'),
(21, 'yashwant', 8169193110, 'adina', 'West Bengal', 'malda', '65416541', 454586125, 'yashwant'),
(22, 'krishna', 8169193111, 'tissa', 'HIMACHAL PRADESH', 'Chamba', '24685435', 248654352, 'krishna'),
(23, 'Abhishek', 8169193101, 'ganeshpuri', 'MAHARASHTRA', 'Thane', '1234567890', 2147483647, 'Abhishek');

CREATE TABLE `orders` (
  `order_id` int(255) NOT NULL,
  `product_id` int(255) NOT NULL,
  `qty` int(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `delivery` varchar(10) NOT NULL,
  `phonenumber` bigint(10) NOT NULL,
  `total` int(10) NOT NULL,
  `payment` varchar(10) NOT NULL,
  `buyer_phonenumber` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `orders` (`order_id`, `product_id`, `qty`, `address`, `delivery`, `phonenumber`, `total`, `payment`, `buyer_phonenumber`) VALUES
(24, 23, 1, ' Ameerpet', 'Buyer', 8169193101, 56, 'cod', 1234567890),
(25, 28, 1, ' Khairatabad', 'Buyer', 8169193102, 45, 'cod', 1234567899),
(26, 31, 1, 'Musheerabad', 'Buyer', 8169193103, 25, 'cod', 1234567898),
(27, 3, 2, ' Secunderabad', 'nurseryman', 8169193104, 10, 'paytm', 1234567897),
(28, 32, 1, 'kompally', 'Buyer', 8169193105, 10, 'cod', 1234567896);

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `nurseryman_fk` int(255) NOT NULL,
  `product_title` varchar(100) NOT NULL,
  `product_cat` varchar(100) NOT NULL,
  `product_image` text NOT NULL,
  `product_stock` int(100) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_delivery` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `products` (`product_id`, `nurseryman_fk`, `product_title`, `product_cat`, `product_image`, `product_stock`, `product_price`, `product_desc`, `product_delivery`) VALUES
(29, 1, 'peace lily', '8', 'peace lily.jpeg', 1000, 299, 'Best Quality product guarented 100 percent', 'yes'),
(30, 1, 'bonsai', '8', 'bonsai.jpeg', 500, 2500, 'Best Quality bonsai assured',  'no'),
(31, 1, 'rose', '8', 'rose.jpeg', 750, 399, 'Seeds Import from australia , grown with love', 'yes'),
(32, 3, 'tulsi', '8',  'tulsi.jpeg', 100, 150, 'Better than others', 'no'),
(33, 1, 'spray', '10', 'spray.jpg', 200, 220, 'Best spray you will ever find', 'yes'),
(34, 1, 'goldenrod', '8', 'goldenrod.jpeg', 1500, 299, 'Best goldenrod grown in Kashmir and handled with love and care',  'no'),
(35, 1, 'penta', '8', 'penta.jpeg', 2000, 250, 'Thin , Fragrant penta grown with love',  'no'),
(37, 3, 'phlox', '8', 'phlox.jpeg', 2000, 399, 'Grown with love in Ratnagiri',  'yes'),
(38, 1, 'bluestar', '8', 'bluestar.jpeg', 500, 250, 'bluestar so beautyfull ,to die for',  'yes'),
(39, 3, 'red soil', '11',  'red soil.jpg', 1500, 250, 'Best Quality red soil', 'yes'),
(40, 1, 'vermi compost', '11', 'vermi compost.jpg', 1500, 299, 'made with love',  'no'),
(41, 3, 'hanging pot', '12', 'hanging pot.jpg', 250, 220, 'Best Quality hanging pot',  'yes'),
(42, 3, 'pots', '12', 'pots.jpeg', 1500, 200,  'best pots', 'yes');

ALTER TABLE `buyer_registration`
  ADD PRIMARY KEY (`buyer_id`),
  ADD UNIQUE KEY `buyer_username` (`buyer_username`),
  ADD UNIQUE KEY `buyer_phone` (`buyer_phone`);

ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

ALTER TABLE `nurseryregistration`
  ADD UNIQUE KEY `nurseryman_id` (`nurseryman_id`);

ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `phonenumber` (`phonenumber`);

ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `nurseryman_fk` (`nurseryman_fk`);

ALTER TABLE `buyer_registration`
  MODIFY `buyer_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `categories`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

ALTER TABLE `nurserymanregistration`
  MODIFY `nurseryman_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

ALTER TABLE `orders`
  MODIFY `order_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
