<?php
include("../code/functions.php");
?>
<html lang="en">
  
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title >ONLINE SHOPPING SITE FOR NURSERY</title>
    <!-- LINKS -->
    <link rel="icon" href="/img/logo.jpg" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/5fe4827def.js" crossorigin="anonymous"></script>

<style>
    #navbar {

padding: 20px;
color: green;
text-decoration: none;
margin: 20px;
font-size: 25px;
padding-top: 10px;
}

#navbar:hover {
padding: 20px;
color: green;
text-decoration: underline;
margin: 15px;
font-size: 25px;
font-weight: bolder;
padding-top: 10px;
}
.content_item {
    text-align: center;
    justify-content: center;
}
tr {
    display: table-row;
    vertical-align: inherit;
    border-color: inherit;
}
.content_item {
               text-align: center;
               justify-content: center;
}
.table {
        width: 100%;
        border-collapse: collapse;
    }

    .table td,
    .table th {
        padding: 12px 15px;
        border: 0px solid #ddd;
        text-align: center;
        font-size: 16px;
    }

    .table th {
        background-color: #292b2c;
        color: white;
    }

    .table tbody tr:nth-child(even) {
        background-color: #f5f5f5;
    }

    </style>
</head>

<body>
  <!-- navbar -->
  <nav class="navbar navbar-expand-lg bg-light">
    <div class="container">
      <a class="navbar-brand" href="#"><img src="../img/logo.jpg"height="50" width="50" alt=""></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        </li>
          <li class="nav-item">
            <p >NURSERY MAN HOME</p>
          </li>
      </div>
    </div>
  </nav>

  <div class="row py-4" style="text-align:center;">
               <div class="col-md-3 col-sm-12">
                    <a href="nurseryhome.php" id="navbar"><i class="fa fa-home" aria-hidden="true"></i><label>Home</label></a>
               </div>
               <div class="col-md-3 col-sm-12">
                    <a href="myproducts.php" id="navbar"><i class="fa fa-leaf" aria-hidden="true"></i><label>My Products</label></a>
               </div>
               <div class="col-md-3 col-sm-12">
                    <a href="transactions.php" id="navbar"><i class="fa fa-exchange" aria-hidden="true"></i><label>My Transactions</label></a>
               </div>
               <div class="col-md-3 col-sm-12">
                    <a href="callcenter.php" id="navbar"><i class="fa fa-phone fa-rotate-vertical" aria-hidden="true"></i><label>Call Centers/SMS</label></a>
               </div>
          </div>
          


          <br>

          <div style="display:block;">

               <div class=content_item><label style="font-size :30px; text-shadow: 1px 1px 1px gray;"><b>TRANSACTION HISTORY</b></label></div>
               <br>
          </div>


          <div class="container">

               <table class="table">
                    <thead>
                         <th>Product Name</th>
                         <th>Name</th>
                         <th>Phone Number</th>
                         <th>Delivery Address</th>
                         <th>Quantity</th>
                         <th>Amount</th>
                    </thead>


                    <tbody>
                         <?php

                         global $con;
                         if (isset($_SESSION['phonenumber'])) {
                              $sess_phone_number = $_SESSION['phonenumber'];
                              $sel_price = "select * from orders where phonenumber = '$sess_phone_number'";
                              $run_price = mysqli_query($con, $sel_price);
                              $i = 0;

                              while ($p_price = mysqli_fetch_array($run_price)) {
                                   $product_id = $p_price['product_id'];
                                   $qty = $p_price['qty'];
                                   $total = $p_price['total'];
                                   $address = $p_price['address'];
                                   $phone = $p_price['buyer_phonenumber'];


                                   $pro_price = "select * from products where product_id='$product_id'";
                                   $run_pro_price = mysqli_query($con, $pro_price);
                                   while ($pp_price = mysqli_fetch_array($run_pro_price)) {
                                        $product_title = $pp_price['product_title'];


                                        $query_name = "select * from buyer_registration where buyer_phone = $phone";
                                        $run_query_name = mysqli_query($con, $query_name);
                                        while ($names = mysqli_fetch_array($run_query_name)) {
                                             $buyer_name = $names['buyer_name'];


                         ?>
                                             <tr>
                                                  <td data-label="Product Name"><?php echo $product_title; ?></td>
                                                  <td data-label="Name"><?php echo $buyer_name; ?></td>
                                                  <td data-label="Phone Number"><?php echo $phone; ?></td>
                                                  <td data-label="Address"><?php echo $address; ?></td>
                                                  <td data-label="Quantity"><?php echo $qty; ?></td>
                                                  <td data-label="Price"><?php echo $total; ?></td>
                                             </tr>


                    </tbody>
<?php
                                        }
                                   }
                                   $i++;
                              }
                         } else {
                              echo "<h1 align = center>Please Login First!</h1><br><br><hr>";
                         } ?>
               </table>
          </div>


<!--footer-->
<footer class="mt-5 py-1">
  <div class="row container mx-auto pt-5">
    <div class="footer-one col-lg-3 col-md-6 col-12">
      <img src="../img/logo.jpg">
      <p>The website where you can buy all different types of plants in single place. Can buy seeds, pots, necessary tools and fertilizers.</p>
    </div>
   <div class="footer-one col-lg-3 col-md-6 col-12">
     <h6 class="pb-2">Featured</h6>
     <ul class="text-uppercase list-unstyled">
       <li><a href="#">plants</a></li>
       <li><a href="#">fertilizers</a></li>
       <li><a href="#">pots</a></li>
       <li><a href="#">seeds</a></li>
       <li><a href="#">pebbles</a></li>
       <li><a href="#">accessories</a></li>
      </ul>
   </div>
   <div class="footer-one col-lg-3 col-md-6 col-12">
      <h6 class="pb-2" >MADE BY:</h6>
     <div>
       <h6 class="text-uppercase"> team members:</h6>
       <p>B.NARESH<br>A.KARTHIK<br>K.SAI PUNEETH</p>
     </div>
     <div>
       <h6 class="text-uppercase"> mail id:</h6>
       <p>20H51A0532@cmrcet.ac.in<br>20H51A0536@cmrcet.ac.in<br>20H51A0596@cmrcet.ac.in</p>
     </div>
   </div>
  </div>
  <div class="row container mx-autp">
    <div class="col-lg-3 col-md-6 col-12">
      <img src="../img/payment.jpg" height="100" width="500">
     </div>
   
  </div>
</footer>
</body>
</html>