<?php
     include("../code/functions.php");
     ?>

<html lang="en">
  
  <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title >ONLINE SHOPPING SITE FOR NURSERY</title>
      <!-- LINKS -->
      <link rel="icon" href="/img/logo.jpg" type="image/x-icon">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" 
      rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
      <link rel="stylesheet" href="style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
  <script src="https://kit.fontawesome.com/5fe4827def.js" crossorigin="anonymous"></script>
  <style>
    #navbar {

padding: 20px;
color: green;
text-decoration: none;
margin: 20px;
font-size: 25px;
padding-top: 10px;
}

#navbar:hover {
padding: 20px;
color: green;
text-decoration: underline;
margin: 15px;
font-size: 25px;
font-weight: bolder;
padding-top: 10px;
}
.content_item {
    text-align: center;
    justify-content: center;
}
.products {
               margin-left: 9%;

          }

          .productbox {
               float: left;
               margin: 15px;
               /* margin-left: 30px; */
               padding: 15px;
               border-style: outline;
               border: 2px solid;
               border-color: black;
               border-radius: 10px;
          }

          .productbox img {
               height: 200px;
               width: 250px;
               border-style: double;
               border: 2px solid;
               border-color:black;
               border-width: 2px;
               border-radius: 10px;
          }

          .productbox p {
               text-align: center;
               text-decoration: underline;
          }

          .productbox img:hover {
               height: 200px;
               width: 250px;
               border-style: double;
               border: 2px solid;
               border-color: black;
               border-width: 2px;
               border-radius: 10px;
          }

          .productbox p:hover {
               text-align: center;
               text-decoration: underline;

          }
    </style>
  </head>
  <body>
     <!-- navbar -->
  <nav class="navbar navbar-expand-lg bg-light">
    <div class="container">
      <a class="navbar-brand" href="#"><img src="../img/logo.jpg"height="50" width="50" alt=""></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        </li>
          <li class="nav-item">
            <p >NURSERY MAN HOME</p>
          </li>
      </div>
    </div>
  </nav>

  <div class="row my-4" style="text-align:center;">
                <div class="col-md-3 col-sm-12">
                     <a href="nurseryhome.php" id="navbar"><i class="fa fa-home" aria-hidden="true"></i><label>Home</label></a>
                </div>
                <div class="col-md-3 col-sm-12">
                     <a href="myproducts.php" id="navbar"><i class="fa fa-leaf" aria-hidden="true"></i><label>My Products</label></a>
                </div>
                <div class="col-md-3 col-sm-12">
                     <a href="transactions.php" id="navbar"><i class="fa fa-exchange" aria-hidden="true"></i><label>My Transactions</label></a>
                </div>
                <div class="col-md-3 col-sm-12">
                     <a href="callcenter.php" id="navbar"><i class="fa fa-phone fa-rotate-vertical" aria-hidden="true"></i><label>Call Centers/SMS</label></a>
                </div>
  </div>

  <div class=content_item>
               <label style="font-size :30px; text-shadow: 1px 1px 1px gray;"><b>All Products</b></label>
               <?php
               include("../code/db.php");
               if (isset($_SESSION['phonenumber'])) {

                    echo "<a href='../code/insertproduct.php'>
                    <button class='btn btn-warning btn-lg p-3 m-3 font-weight-bold' style='background-color:#fb774b'>Add New Product <i class='fas fa-plus-square p-2 fa-1x'></i>
                    </button>
                    </a>
                    <a href='../code/delectproduct.php'>
                    <button class='btn btn-warning btn-lg p-3 m-3 font-weight-bold' style='background-color:#fb774b'>delect Product 
                    </button>
                    </a>";
               } else {
                    echo "<a href='../code/nurserylogin.php'>
                    <button class='btn btn-warning btn-lg p-3 m-3 font-weight-bold'>Add New Product <i class='fas fa-plus-square p-2 fa-1x'></i>
                    </button>
                    </a>";
               }
               ?>

  </div>

          <br>
          <main>
               <div class="products">
                    <?php
                    include("../code/db.php");
                    if (isset($_SESSION['phonenumber'])) {
                         $sess_phone_number = $_SESSION['phonenumber'];
                         getnurseryProducts();
                    } else {
                         echo "<br><br><h1 align = center>Please Login!</h1><br><br><hr>";
                    }
                    ?>
               </div>
               <br> <br>
               
          </main>
          </body>
  <!--footer
  <footer class="mt-5 py-1">
        <div class="row container mx-auto pt-5">
          <div class="footer-one col-lg-3 col-md-6 col-12">
            <img src="../img/logo.jpg">
            <p>The website where you can buy all different types of plants in single place.can buy seeds,pots,necessary tools and fertilizers.</p>
          </div>
         <div class="footer-one col-lg-3 col-md-6 col-12">
           <h6 class="pb-2">featured</h6>
           <ul class="text-uppercase list-unstyled">
             <li><a href="#">plants</a></li>
             <li><a href="#">fertilizers</a></li>
             <li><a href="#">pots</a></li>
             <li><a href="#">seeds</a></li>
             <li><a href="#">pebbles</a></li>
             <li><a href="#">accessories</a></li>
            </ul>
         </div>
         <div class="footer-one col-lg-3 col-md-6 col-12">
            <h6 class="pb-2" >MADE BY:</h6>
           <div>
             <h6 class="text-uppercase"> team members:</h6>
             <p>B.NARESH<br>A.KARTHIK<br>K.SAI PUNEETH</p>
           </div>
           <div>
             <h6 class="text-uppercase"> mail id:</h6>
             <p>20H51A0532@cmrcet.ac.in<br>20H51A0536@cmrcet.ac.in<br>20H51A0596@cmrcet.ac.in</p>
           </div>
         </div>
        </div>
        <div class="row container mx-autp">
          <div class="col-lg-3 col-md-6 col-12">
            <img src="../img/payment.jpg" height="100" width="500">
           </div>
         
        </div>
  </footer>-->
  
  </html>