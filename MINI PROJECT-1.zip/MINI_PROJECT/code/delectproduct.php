<?php
include("../code/functions.php");
$sess_phone_number = $_SESSION['phonenumber'];

global $con;
        $sess_phone_number = $_SESSION['phonenumber'];
        $query = "select * from products where nurseryman_fk in (select nurseryman_id from nurseryregistration where nurseryman_phone=$sess_phone_number) ";
        $run_query = mysqli_query($con, $query);
        $count = 0;
        if ($run_query) {
            while ($row = mysqli_fetch_assoc($run_query)) {
                $count = $count + 1;
                $product_title =  $row['product_title'];
                $image =  $row['product_image'];
                $price =  $row['product_price'];
                $id =     $row['product_id'];
                $nurseryman_fk = $row['nurseryman_fk'];
                $path = "../img/best product/" . $image;
            }
            $delete_product = "delete from products where  product_id = '$product_id' and nurseryman_fk = '$nurseryman_fk'";
            $run_delete = mysqli_query($con, $delete_product);
          }

?>



