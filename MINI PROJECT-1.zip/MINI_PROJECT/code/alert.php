<?php
echo "<script>alert('Cart Is Empty');</script>";
echo "<script>window.open('../code/buyerhome.php','_self');</script>";

?>