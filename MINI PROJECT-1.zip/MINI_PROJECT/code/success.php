<?php
include("../code/functions.php");
?>
<html lang="en">
  
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title >ONLINE SHOPPING SITE FOR NURSERY</title>
    <!-- LINKS -->
    <link rel="icon" href="/img/logo.jpg" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/5fe4827def.js" crossorigin="anonymous"></script>
</head>

<body>
  <!-- navbar -->
  <nav class="navbar navbar-expand-lg bg-light">
    <div class="container">
      <a class="navbar-brand" href="#"><img src="../img/logo.jpg"height="50" width="50" alt=""></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a href="index.html" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">Home</a>
            <!-- <a class="nav-link active" aria-current="page" href="#">home</a> -->
          
          </li>
          <li class="nav-item">
            <a href="shop.html" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">Shop</a>
           <!-- <a class="nav-link active" aria-current="page" href="#">Shop</a> -->
          </li>
          <li class="nav-item">
            <a href="buyerprofile.php" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">Profile</a>
            <!-- <a class="nav-link active" aria-current="page" href="#">profile</a> -->
          </li>
          <!---->
          <div class="dropdown">
            <button class="btn btn-dark dropdown-toggle me-md-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
              Products
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">Plants</a></li>
              <li><a class="dropdown-item" href="#">Gardening tools</a></li>
              <li><a class="dropdown-item" href="#">Fertilizers</a></li>
            </ul>
          </div>
          <li class="nav-item">
            <a href="cart.php" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">cart</a>
            <!-- <a class="nav-link active" aria-current="page" href="#">profile</a> -->
          </li>
          
        </ul>
        <!-- search bar -->
        <form class="d-flex" role="search">
      <input class="form-control me-2"  type="search" id="search-item" placeholder="Search products " aria-label="Search" onkeyup="search()">
          <button class="btn btn-outline-success" type="submit">  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
             class="bi bi-search" viewBox="0 0 16 16">
            <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007
            1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
           </svg></button>
        </form>
      </div>
    </div>
  </nav>

  <div class="card">
            <h4 class="card-header text-success text-center font-weight-bold">Success</h4>
            <div class="card-body">
                 <h4 class="card-title text-success text-center font-weight-bold">Product Successfully Added</h4>
                 <h5 class="card-text text-center">Thankyou For Shopping With Us.</h5>
                 <br>
                 <div class="form-actions">
                      <a href="buyerhome.php" class="btn btn-success btn-lg ">Go To Home</a>
                 </div>
            </div>
       </div>

</body>
</html>