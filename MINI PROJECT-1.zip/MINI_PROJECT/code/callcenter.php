<?php
include("../code/functions.php");
?>
<html lang="en">
  
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title >ONLINE SHOPPING SITE FOR NURSERY</title>
    <!-- LINKS -->
    <link rel="icon" href="/img/logo.jpg" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/5fe4827def.js" crossorigin="anonymous"></script>
<style>
    #navbar {

padding: 20px;
color: green;
text-decoration: none;
margin: 20px;
font-size: 25px;
padding-top: 10px;
}

#navbar:hover {
padding: 20px;
color: green;
text-decoration: underline;
margin: 15px;
font-size: 25px;
font-weight: bolder;
padding-top: 10px;
}
tr {
    display: table-row;
    vertical-align: inherit;
    border-color: inherit;
}
</style>
</head>

<body>
  <!-- navbar -->
  <nav class="navbar navbar-expand-lg bg-light">
    <div class="container">
      <a class="navbar-brand" href="#"><img src="../img/logo.jpg"height="50" width="50" alt=""></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        </li>
          <li class="nav-item">
            <p >NURSERY MAN HOME</p>
          </li>
      </div>
    </div>
  </nav>

  <div class="row py-4" style="text-align:center;">
               <div class="col-md-3 col-sm-12">
                    <a href="nurseryhome.php" id="navbar"><i class="fa fa-home" aria-hidden="true"></i><label>Home</label></a>
               </div>
               <div class="col-md-3 col-sm-12">
                    <a href="myproducts.php" id="navbar"><i class="fa fa-leaf" aria-hidden="true"></i><label>My Products</label></a>
               </div>
               <div class="col-md-3 col-sm-12">
                    <a href="transactions.php" id="navbar"><i class="fa fa-exchange" aria-hidden="true"></i><label>My Transactions</label></a>
               </div>
               <div class="col-md-3 col-sm-12">
                    <a href="callcenter.php" id="navbar"><i class="fa fa-phone fa-rotate-vertical" aria-hidden="true"></i><label>Call Centers/SMS</label></a>
               </div>
          </div>

          <div class="card">
               <h4 class="card-header text-center font-weight-bold">SMS System</h4>
               <div class="card-body">
                    <h5 class="card-title text-center font-weight-bold">You Can Upload Sms by using Following Syntax</h5>
                    <div class="card-deck">
                         <div class="card">

                              <div class="card-body">
                                   <h5 class="card-title font-weight-bold text-center">Insert Product</h5>
                                   <p class="card-text">*#*,insert,password,product title,product category , product type , product stock ,MRP,Base Price, product keywords , product description ,product delivery</p>

                              </div>
                         </div>
                         <div class="card">

                              <div class="card-body">
                                   <h5 class="card-title font-weight-bold text-center">Update Product</h5>
                                   <p class="card-text">*#*,update,password,product title,product category , product type , product stock ,MRP,Base Price, product keywords , product description ,product delivery</p>

                              </div>
                         </div>
                         <div class="card">

                              <div class="card-body">
                                   <h5 class="card-title font-weight-bold text-center">Delete Product</h5>
                                   <p class="card-text">*#*,delete,password,product title,MRP</p>
                                   <p></p>
                                   <p></p>
                              </div>
                         </div>
                    </div>
               </div>
          </div>
          <br>
          <br>

          <div style="display:block;">

               <div class=content_item><label style="font-size :30px; text-shadow: 1px 1px 1px gray;"><b>Call Center , Location's & Langauges</b></label></div>
               <br>

               <br>
               <h4 align="center">Toll Free Number : 1800564999</h4>
               <br>
               <table class="table">
                    <thead align="center" class=tableyhead>
                         <th class=thy>SR NO.</th>
                         <th class=thy>LOCATION</th>
                         <th class=thy>STATES</th>
                         <th class=thy>LANGUAGES</th>


                    </thead>
                    <tr align="center" class=trow>
                         <th align="center">1</th>
                         <th align="center">Hyderabad</th>
                         <th align="center">Andhra Pradesh</th>
                         <th align="center">Telugu</th>

                    </tr>
                    <tr align="center" class=trow>
                         <th align="center">2</th>
                         <th align="center">Patna</th>
                         <th align="center">Bihar | Jharkhand</th>
                         <th align="center">Hindi</th>


                    </tr>
                    <tr align="center" class=trow>
                         <th align="center">3</th>
                         <th align="center">Jaipur</th>
                         <th align="center">Delhi | Rajasthan</th>
                         <th align="center">Hindi</th>

                    </tr>
                    <tr align="center" class=trow>
                         <th align="center">4</th>
                         <th align="center">Ahmadabad/Anand</th>
                         <th align="center">Gujarat | Dadra & Nagar Haveli | Daman & Diu</th>
                         <th align="center">Gujarati | Goan</th>

                    </tr>
                    <tr align="center" class=trow>
                         <th align="center">5</th>
                         <th align="center">Chandigarh</th>
                         <th align="center">Haryana | Punjab | Chandigarh | Himachal Pradesh</th>
                         <th align="center">Hindi/Haryanvi | Punjabi | Hindi</th>

                    </tr>
                    <tr align="center" class=trow>
                         <th align="center">6</th>
                         <th align="center">Jammu</th>
                         <th align="center">Jammu and Kashmir</th>
                         <th align="center">Dogri, Kashmiri, Ladakh</th>

                    </tr>
                    <tr align="center" class=trow>
                         <th align="center">7</th>
                         <th align="center">Bangalore</th>
                         <th align="center">Karnataka | Kerala | Lakshadweep</th>
                         <th align="center">Kannada | Malayalam</th>

                    </tr>
                    <tr align="center" class=trow>
                         <th align="center">8</th>
                         <th align="center">Jabalpur</th>
                         <th align="center">Madhya Pradesh | Chhattisgarh</th>
                         <th align="center">Hindi</th>

                    </tr>
                    <tr align="center" class=trow>
                         <th align="center">9</th>
                         <th align="center">Nagpur/Pune</th>
                         <th align="center">Maharashtra | Goa</th>
                         <th align="center">Marathi | Goan</th>

                    </tr>
                    <tr align="center" class=trow>
                         <th align="center">10</th>
                         <th align="center">Coimbatore</th>
                         <th align="center">Tamil Nadu | Puducherry | Andaman & Nicobar</th>
                         <th align="center">Tamil</th>

                    </tr>
                    <tr align="center" class=trow>
                         <th align="center">11</th>
                         <th align="center">Kanpur</th>
                         <th align="center">Uttar Pradesh | Uttarakhand</th>
                         <th align="center">Hindi</th>

                    </tr>
                    <tr align="center" class=trow>
                         <th align="center">12</th>
                         <th align="center">Kolkata</th>
                         <th align="center">West Bengal | Sikkim</th>
                         <th align="center">Bengali | Sikkimese</th>

                    </tr>
                    <tr align="center" class=trow>
                         <th align="center">13</th>
                         <th align="center">Bhubaneshwar</th>
                         <th align="center">Orissa</th>
                         <th align="center">Oriya</th>

                    </tr>
                    <tr align="center" class=trow>
                         <th align="center">14</th>
                         <th align="center">Guwahati</th>
                         <th align="center">Arunachal Pradesh | Assam | Manipur | Meghalaya | Mizoram | Nagaland | Tripura</th>
                         <th align="center">Adi | Assamese | Manipuri | Khasi | Mizo | Nagamese | Bengali</th>

                    </tr>

               </table>
          </div>
    <!--footer-->
 <footer class="mt-5 py-1">
  <div class="row container mx-auto pt-5">
    <div class="footer-one col-lg-3 col-md-6 col-12">
      <img src="../img/logo.jpg">
      <p>The website where you can buy all different types of plants in single place. Can buy seeds, pots, necessary tools and fertilizers.</p>
    </div>
   <div class="footer-one col-lg-3 col-md-6 col-12">
     <h6 class="pb-2">Featured</h6>
     <ul class="text-uppercase list-unstyled">
       <li><a href="#">plants</a></li>
       <li><a href="#">fertilizers</a></li>
       <li><a href="#">pots</a></li>
       <li><a href="#">seeds</a></li>
       <li><a href="#">pebbles</a></li>
       <li><a href="#">accessories</a></li>
      </ul>
   </div>
   <div class="footer-one col-lg-3 col-md-6 col-12">
      <h6 class="pb-2" >MADE BY:</h6>
     <div>
       <h6 class="text-uppercase"> team members:</h6>
       <p>B.NARESH<br>A.KARTHIK<br>K.SAI PUNEETH</p>
     </div>
     <div>
       <h6 class="text-uppercase"> mail id:</h6>
       <p>20H51A0532@cmrcet.ac.in<br>20H51A0536@cmrcet.ac.in<br>20H51A0596@cmrcet.ac.in</p>
     </div>
   </div>
  </div>
  <div class="row container mx-autp">
    <div class="col-lg-3 col-md-6 col-12">
      <img src="../img/payment.jpg" height="100" width="500">
     </div>
   
  </div>
</footer>

</body>
</html>