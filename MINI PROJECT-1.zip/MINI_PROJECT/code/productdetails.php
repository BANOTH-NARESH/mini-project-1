<?php

include("../code/functions.php");
?>

<html lang="en">
  
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title >ONLINE SHOPPING SITE FOR NURSERY</title>
    <!-- LINKS -->
    <link rel="icon" href="/img/logo.jpg" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/5fe4827def.js" crossorigin="anonymous"></script>
<style>
    .btn-warning {
    --bs-btn-color: #000;
    --bs-btn-bg: #fb774b;
    --bs-btn-border-color: #ffc107;
    --bs-btn-hover-color: #000;
    --bs-btn-hover-bg: #fb774b;
    --bs-btn-hover-border-color: #ffc720;
    --bs-btn-focus-shadow-rgb: 217,164,6;
    --bs-btn-active-color: #000;
    --bs-btn-active-bg: #ffcd39;
    --bs-btn-active-border-color: #ffc720;
    --bs-btn-active-shadow: inset 0 3px 5pxrgba(0, 0, 0, 0.125);
    --bs-btn-disabled-color: #000;
    --bs-btn-disabled-bg: #ffc107;
    --bs-btn-disabled-border-color: #ffc107;
}
.bg-warning {
    --bs-bg-opacity: 1;
    background-color: rgba(var(--bs-warning-rgb),var(--bs-bg-opacity))!important;
}
    </style>
</head>

<body>
    <!--navbar-->
<nav class="navbar navbar-expand-lg bg-light">
    <div class="container">
      <a class="navbar-brand" href="#"><img src="../img/logo.jpg"height="50" width="50" alt=""></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a href="buyerhome.php" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">Home</a>
            <!-- <a class="nav-link active" aria-current="page" href="#">home</a> -->
          
          </li>
          <li class="nav-item">
            <a href="shop.html" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">Shop</a>
           <!-- <a class="nav-link active" aria-current="page" href="#">Shop</a> -->
          </li>
          <li class="nav-item">
            <a href="#" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">Profile</a>
            <!-- <a class="nav-link active" aria-current="page" href="#">profile</a> -->
          </li>
          <!---->
          <div class="dropdown">
            <button class="btn btn-dark dropdown-toggle me-md-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
              Products
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">Plants</a></li>
              <li><a class="dropdown-item" href="#">Gardening tools</a></li>
              <li><a class="dropdown-item" href="#">Fertilizers</a></li>
            </ul>
          </div>
          <li class="nav-item">
            <a href="cart.php" class="btn btn-dark me-md-2" tabindex="-1" role="button" aria-disabled="true">cart</a>
            <!-- <a class="nav-link active" aria-current="page" href="#">profile</a> -->
          </li>
          
        </ul>
        <!-- search bar -->
        <form class="d-flex" role="search">
      <input class="form-control me-2"  type="search" id="search-item" placeholder="Search products " aria-label="Search" onkeyup="search()">
          <button class="btn btn-outline-success" type="submit">  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
             class="bi bi-search" viewBox="0 0 16 16">
            <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007
            1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
           </svg></button>
        </form>
      </div>
    </div>
</nav>

  <?php


 if (isset($_GET['id'])) {
    
    $product_id  = $_GET['id'];
    $query = "select * from products where product_id = $product_id";
    $run_query = mysqli_query($con, $query);
    echo "<br>";
    while ($rows = mysqli_fetch_array($run_query)) {
        $nurseryman_fk = $rows['nurseryman_fk'];
        $product_title = $rows['product_title'];
        $product_image = $rows['product_image'];
        $product_price = $rows['product_price'];
        $product_stock = $rows['product_stock'];
        $product_delivery = $rows['product_delivery'];
        $product_desc = $rows['product_desc'];
        if ($product_delivery == "yes") {
            $product_delivery = "Delivery by nurseryman";
        } else {
            $product_delivery = "Delivery by nurseryman Not Available";
        }
        $querya = "select * from nurseryregistration where nurseryman_id = $nurseryman_fk";
        $runa_query = mysqli_query($con, $querya);

        while ($rows = mysqli_fetch_array($runa_query)) {
            $name = $rows['nurseryman_name'];
            $phone = $rows['nurseryman_phone'];
            $address = $rows['nurseryman_address'];
            $state = $rows['nurseryman_state'];
            $district = $rows['nurseryman_district'];


            echo "
            <div class='container'>
                <div class='text-center'>
                    <br>
                    <h1 id='headings' class='font-weight-bold'>$product_title</h1>
                </div>
                <br>


                <div class='row'>
                    <div class='col-12 col-xl-4 col-lg-4 col-md-4 col-sm-12   imageblock border border-dark'> <img src='../img/best products/$product_image' class='d-flex mx-auto btn-dark image' height='290px;' width='380px;'><br>
                        <b>
                           
                        </b></div>

                    <div class='col-12 col-xl-4 col-lg-4 col-md-4 col-sm-12 block border border-dark'>
                        <div class='text-center mt-2 ''>
                        
                            <br>
                            <div class='row'>
                                <div class='col-12 col-xl-6 col-lg-6 col-md-6 col-sm-12 price'>
                                    <h5><b>Price : </b>$product_price </h5>

                                </div>
                                <div class='col-12 col-xl-6 col-lg-6 col-md-6 col-sm-12 stock'>
                                    <h5><b>Stock : </b>$product_stock </h5>
                                </div>
                            </div>
                            <form actions='' method='post'>
                                <div class='text-center'>
                                    <div class='input-group mb-3 wholequantity'>
                                        <div class='input-group-prepend quantity'>
                                            <span class='input-group-text bg-warning border-secondary quantitylabel' style='color:black' id='inputGroup-sizing-default' ><b>Quantity </b><i class='fas fa-shopping-bag'></i></span>
                                        </div>
                                        <input type='number' name='qty' placeholder=1 class='form-control quantitynumber' aria-label='Default' aria-describedby='inputGroup-sizing-default'>
                                    </div>
                                </div>
                                <div class='row'>
                                    <div class='col-12 col-xl-6 col-lg-6 col-md-6 col-sm-12'> 
                                        <button name='cart' type='submit' class='btn btn-warning border-secondary addtocart' style='color:black'><b>Add to cart</b><i class='fa' style='font-size:17px; '>&#61562;</i></button>
                                    </div>
                                    <div class='col-12 col-xl-6 col-lg-6 col-md-6 col-sm-12'> <a href='#' class='btn btn-warning border-secondary saveforlater' style='color:black'><b>Save For later</b></a></div>
                                </div>
                            </form>
                            <div class='row text-center ml-4 mt-3'>
                                <i class='fa fa-truck fa-2x'></i>
                                <h3 style='padding-left:9px;'>$product_delivery</h3>
                            </div>
                              <div class='row text-center ml-4 mt-3'>
                               <i class='fas fa-map-marker-alt fa-1x'></i>
                                <h5 style='padding-left:9px;'>$district , $state </h5>
                            </div>

                        </div>
                    </div>
                    <div class='col-12 col-xl-4 col-lg-4 col-md-4 col-sm-12 text-white' style='background-color:#292b2c;'>
                        <div class='text-center Nurserydetails mt-4 ' style='color:white'><b>
                                <b>
                                    <h2>Nursery Details
                                    </h2>
                                </b>
                            </b>
                        </div>
                        <div class='details mt-1 text-center'>
                            <h5 style='color:white'><b> Name </b><span style='color:ghostwhite'>: $name</span></h5>

                            <h5 style='color:white'><b> Phone Number </b><span style='color:ghostwhite'>:$phone</span></h5>
                            <br>
                            <h4 style='color:white' class='text-center '>Get In touch with Nursery</h4>
                            <a href='BuyerPageFarmerProfile.php' class='btn btn-warning border-secondary  chat' style='color:white;padding:2px;'><b> View nursery Profile <i class='fas fa-id-card-alt pl-1'></i> </b></a>

                            <h4 style='color:white' class='text-center ''>Have Some Query ?<br></h4>
                            <a href='#' class='btn btn-warning border-secondary  chat' style='color:white;padding:2px;'><b>CHAT HERE</b></a>

                            <!-- <b> Address</b> : Lorem ipsum dolor, sit Eum, ad eaque earum voluptates nemo vero possimus, dolor aspernatur ea aut quisquam quas consequuntur distinctio! -->
                        </div>
                    </div>
                </div>

                <br><br>
                <div class='  description mt-0'><b>
                        <h2 class='text-center font-weight-bold'>Description</h2>
                    </b></div>
                <br>
                <div class='texty' style='margin-top:0%; font-size:25px;'> $product_desc.</div>

                
            </div>";
        }
    }
}

if (isset($_POST['cart'])) {

    if (isset($_POST['quantity'])) {
        $qty = $_POST['quantity'];
    } else {
        $qty = 1;
    }
    
    if (isset($_SESSION['phonenumber'])) {
        $sess_phone_number = $_SESSION['phonenumber'];

        $check_pro = "select * from cart where phonenumber = $sess_phone_number and product_id='$product_id' ";

        $run_check = mysqli_query($con, $check_pro);

        if (mysqli_num_rows($run_check) > 0) {
            echo "";
        } else {
            $subtotal = $product_price * $qty;
            $insert_pro = "insert into cart (product_id,phonenumber,qty,subtotal) values ('$product_id','$sess_phone_number','$qty','$subtotal')";
            $run_insert_pro = mysqli_query($con, $insert_pro);
            echo "<script>window.location.reload(true)</script>";
        }
    } else {
        echo "<script>window.alert('Please Login First!');</script>";
    }
}
?>


</body>
</html>